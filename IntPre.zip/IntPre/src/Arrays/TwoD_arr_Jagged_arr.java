package Arrays;

public class TwoD_arr_Jagged_arr {

	public static void main(String[] args) {
		//***************MATRIX ARRAY*****************
		int [][]arr;  //declaration
		arr=new int[2][]; //Creation 
		arr[0]=new int[3];
		arr[1]=new int[4];
		
		arr[0][2]=65;
		arr[1][3]=61;
		
		
		
	
		
		//Declaration and Creation in one line
		int [][]array2=new int[2][];
		//after that we need to give column size 
		arr[0]=new int[3];
		arr[1]=new int[4];
		//Declaration ,Creation,Initialization in one line
		int [][]array3= {{12,54,34},{54,76,32,43}};
		
		System.out.println(array3[0][1]);//54
		System.out.println(array3.length);//2
		System.out.println(array3[0].length);//3
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(array3[i][j] + " ");
			}
			System.out.println("");
		}

	}

}
