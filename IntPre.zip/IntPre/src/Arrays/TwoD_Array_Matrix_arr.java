package Arrays;

public class TwoD_Array_Matrix_arr {

	public static void main(String[] args) {
		//***************MATRIX ARRAY*****************
		int [][]arr;  //declaration
		arr=new int[3][3]; //Creation 
		
		arr[0][0]=34; //initialization
		arr[0][1]=12;
		arr[0][2]=54;
		
		arr[1][0]=34;
		arr[1][1]=12;
		arr[1][2]=54;
		
		arr[2][0]=34;
		arr[2][1]=12;
		arr[2][2]=54;
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j] + " ");
			}
			System.out.println("");
		}

		//Declaration and Creation in one line
		int [][]array2=new int[2][3];
		//Declaration ,Creation,Initialization in one line
		int [][]array3= {{12,54,34},{54,76,32}};
		
		
		for(int i=0;i<array3.length;i++)
		{
			for(int j=0;j<array3[i].length;j++)
			{
				System.out.print(array3[i][j] + " ");
			}
			System.out.println("");
		}

	}

}
