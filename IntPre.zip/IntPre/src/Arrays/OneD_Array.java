package Arrays;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class OneD_Array 
{
	public static void main(String[] args)
	{
		int[] arr = new int[4];
		int sum = 0;
		int[] res = new int[0];
		arr[0] = 45;
		arr[1] = 66;
		arr[2] = 45;
		arr[3] = 67;
		System.out.println(arr[1]);
		for (int list : arr) {
			System.out.println(list);
		}
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}
		System.out.println(sum);

		System.out.println("Duplicate element from array");
		// Duplicates elements from the Array
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					System.out.println(arr[i] + " ");
					break;
				}
			}

		}
		// Unique elements from the array
		// Using HashMap
		System.out.println("unique element using hashmap");
		HashMap<Integer, Integer> hashmap = new HashMap<>();
		for (int i = 0; i < arr.length; i++) {
			hashmap.put(arr[i], i);
		}
		System.out.println(hashmap.keySet());

		// Unique elements from the array
		// Using nested loop
		int[] distinctArray = new int[20]; 
		int index=0;
		System.out.println("unique element using nested loop");
		for (int i = 0; i < arr.length; i++) 
		{
			int flag=0;
			for(int j=0;j<i;j++)
			{
				if(arr[i]==arr[j])
				{
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				distinctArray[index]=arr[i];
				index++;
			}
		}
		for(int i=0; i<index;i++)
		{
			System.out.print(distinctArray[i] +" ");
		}
		System.out.println("");
		
		// Unique elements from the array Using HashMap
		System.out.println("unique element using HashSet");
		int []array= {55,34,56,34,76,23,13};
		int len=array.length;
		HashSet<Integer> hashset=new HashSet<>();
		
		for(int i=0;i<len;i++)
		{
			if(!hashset.contains(array[i]))
			{
				hashset.add(array[i]);
			}
		}
		System.out.println(hashset);
		
		//Take a input element user from user
		Scanner sc=new Scanner(System.in);
		int arr2[]=new int[6];
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Enter a element");
			arr[i]=sc.nextInt();
		}
	}

}
