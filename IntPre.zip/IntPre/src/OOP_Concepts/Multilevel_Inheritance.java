package OOP_Concepts;

//MultiLevel Inheritance 
class Animal
{
	void eat()
	{
	   System.out.println("The Animal eats food");
	}
}
class Cat extends Animal
{
	void walk()
	{
		System.out.println("the cat driking milk");
	}
}
class Dog extends Cat
{
	void bark()
	{
		System.out.println("The dog eating Roti");
	}
}

public class Multilevel_Inheritance {

	public static void main(String[] args) {
		Dog d=new Dog();
		d.eat();
		d.walk();
		d.bark();
	}

}
