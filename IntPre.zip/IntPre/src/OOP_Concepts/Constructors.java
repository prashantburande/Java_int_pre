package OOP_Concepts;


class Employee
{
	String empNam;
	int sal;
	int empID;
	String empAdress;
	
	//Default Constructor
	//if any constructor defined explicitly then default constructor won't be create.
	//below two constructor not available the default constructor will work with taking above
	//default value.
	
	//parameterLess constructor
	//Manually defined by programmer
	Employee() 
	{
		this.empNam = "defaultName";
		this.sal = 0;
		this.empID = 0;
		this.empAdress = "defaultAdress";
	}
	
	//Parameterized constructor
	public Employee(String empNam, int sal, int empID, String empAdress) {
		this.empNam = empNam;
		this.sal = sal;
		this.empID = empID;
		this.empAdress = empAdress;
	}
	@Override
	public String toString() {
		return "Employee [empNam=" + empNam + ", sal=" + sal + ", empID=" + empID + ", empAdress=" + empAdress + "]";
	}
}

public class Constructors {

	public static void main(String[] args) {
		Employee defCons=new Employee();
		System.out.println("Exployee created using default constructor");
		System.out.println(defCons);
		
		Employee s=new Employee("david",5433,23,"us");
		System.out.println("Employee created using Paramaterized constructor");
		System.out.println(s);

	}

}
