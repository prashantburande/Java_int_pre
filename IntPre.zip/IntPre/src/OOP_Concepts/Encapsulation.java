package OOP_Concepts;

//Encapsulation is wrapping of data variable and methods into single unit;
//Wrapping of data variable means whatever we private variable and method is like getter and setter
//So that private variable and getter-setter method this code act like single entity we are saying 
//wrapping of these things
//using Encapsulation we can achieve data hiding,security 


class Employe
{  
	//Data variable 
	private String name;
	private int age;
	private double salary;
	
	public String getName()
	{
		return name;
	}
    public void setName(String name)
    {
		this.name=name;
	}  
    
    public int getAge()
    {
    	return age;
    }
    public void setAge(int age)
    {
    	if(age>0)
    		this.age=age;
    	else {
    		System.out.println("age should in positive number");
    	}
    }
    
    public double getSalary()
    {
    	return salary;
    }
    public void setSalary(double salary)
    {
    	if(salary>0)
    	{
    		this.salary=salary;
    	}
    	else
    	{
    		System.out.println("Salary should be in positive number");
    	}
    }
	
}
public class Encapsulation {

	public static void main(String[] args) {
		Employe emp=new Employe();
		emp.setName("Prashant");
		emp.setAge(26);
		emp.setSalary(56444);
		
		System.out.println(emp.getName());
		System.out.println(emp.getAge());
		System.out.println(emp.getSalary());

	}

}
