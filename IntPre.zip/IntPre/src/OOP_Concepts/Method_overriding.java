package OOP_Concepts;
/*
 * 2. Runtime Polymorphism
Runtime Polymorphism in Java known as Dynamic Method Dispatch.
 It is a process in which a function call to the overridden method
  is resolved at Runtime. This type of polymorphism is achieved by Method Overriding.
   Method overriding, on the other hand, occurs when a derived class has a definition for 
   one of the member functions of the base class. That base function is said to be overridden.
 if subclass(child class) has the same method as declared in the parent class it's 
 known as method overriding---->if child not satisfied with parent class method so child can declare again
 */

//The method in subclass must be same name method name,return type super class name and return type
//and also same parameter in both parent - child method

class Bank
{
	double getIntrestRate()
	{
		return 0.2;
	}
}
class HDFC extends Bank
{
	double getIntrestRate()
	{
		return 5.2;
	}
}
class SBI extends Bank
{
	double getIntrestRate()
	{
		return 6.2;
	}
}
public class Method_overriding {

	public static void main(String[] args) {
		Bank hdfc=new HDFC();
		Bank sbi=new SBI();
		
		
		System.out.println(hdfc.getIntrestRate());
		System.out.println(sbi.getIntrestRate());
	}

}
