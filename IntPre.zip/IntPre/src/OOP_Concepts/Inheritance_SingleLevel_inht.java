package OOP_Concepts;

//Inheritance is a concept where the properties of one class can be inherited by other class
//Inheritance is a like parent-child relationship 
//child can access the parent properties
//Parent class ->SUPER CLASS Child class->SUB CLASS
//Using "extends" we are achieve Inheritance

//types of inheritance 
//1)Single Level 2)Multilevel 3)Multiple[not directly supported] 4)Hierachical Inheritance 

class Parent
{
	void property()
	{
		System.out.println("This is the parent proprty");
	}
}
class Child extends Parent
{
	void land()
	{
		System.out.println("this is the child land");
	}
}
public class Inheritance_SingleLevel_inht {

	public static void main(String[] args) {
		Child c =new Child();
		c.property();
		c.land();

	}

}
