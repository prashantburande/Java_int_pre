package OOP_Concepts;

/*
 * Types of Java Polymorphism
In Java Polymorphism is mainly divided into two types: 

1)Compile-Time Polymorphism
2)Runtime Polymorphism

 * 1. Compile-Time Polymorphism
Compile-Time Polymorphism in Java is also known as static polymorphism. This type of 
polymorphism is achieved by method overloading or operator overloading. 

Note: But Java doesn’t support the Operator Overloading.
 */

//1)Method overloading by changing the number of arguments
//2)Method overloading by Types of arguments
//3)Method overloading by Types return type
//4)Method overloading by order of arguments
class Calculater {
	// Method overloading by number of arguments
	public void sum() {
		System.out.println("no argument called");
	}

	public int sum(int num1, int num2) {
		return num1 + num2;
	}

	// Method overloading by changing the number of arguments
	public int sum(int num1, int num2, int num3) {
		return num1 + num2 + num3;
	}

	// Method overloading by order of arguments
	public void sum(double num1, int num2) {
		System.out.println(num1 + num2);
	}

	// Method overloading by Types return type
	public double sum(double num1, double num2, double num3) {
		return num1 + num2 + num3;
	}
}

public class Method_Overloading {

	public static void main(String[] args) {
		Calculater c = new Calculater();
		c.sum();
		c.sum(54.7,98);
		System.out.println(c.sum(65,78));
		System.out.println(c.sum(65,78,43));
		System.out.println(c.sum(65.0,78.7,43.87));
	}

}
