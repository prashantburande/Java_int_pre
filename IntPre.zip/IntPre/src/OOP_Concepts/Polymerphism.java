package OOP_Concepts;

//The word ‘polymorphism’ means ‘having many forms’
//polymorphism is nothing but ability of an object to take one or more form.
//In Java, polymorphism refers to the ability of a message to be displayed in more than one form
//

/*
 * Real-life Illustration of Polymorphism in Java: A person can have different
 *  characteristics at the same time. Like a man at the same time is a father,
 *   a husband, and an employee. So the same person possesses different behaviors
 *    in different situations. This is called polymorphism.
 */
//Base class Person
class Person
{
	void role()
	{
		System.out.println("I am Person");
	}
}
//Derived class Father that 
//overrides the role method
class Father extends Person
{
	void role()
	{
		System.out.println("I am Father");
	}
}

public class Polymerphism {

	public static void main(String[] args) {
		// Creating a reference of type Person 
        // but initializing it with Father class object
        Person p = new Father();//upcasting
        
     // Calling the role method. It calls the 
        // overridden version in Father class
        p.role();  	//I am Father
        

	}

}
