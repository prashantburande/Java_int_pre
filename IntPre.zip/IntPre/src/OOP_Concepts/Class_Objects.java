package OOP_Concepts;

//**class**:class is blueprint that defines the structure(data members) and behavior(methods)
//It encapsulate the fields and method into single unit

//**object**:Object is instance of a class and that contains it's own data and behavior 
//objects is created using "new" keyword

class Car
{
	//structure or data members or field or attribute
	String brand;
	String color;
	int topSpeed;
	
	//Constructor
	Car(String brand,String color,int topSpeed){
		this.brand=brand;
		this.color=color;
		this.topSpeed=topSpeed;
	}
	
	//Methods or behavior
	void display()
	{
		System.out.println("car brand is " + brand + " color is " + color + 
				" and top speed is " + topSpeed + "kmph");
	}
}

public class Class_Objects {

	public static void main(String[] args) {
		//creating a object of car class
		Car c=new Car("tesla","black",400);
		//Accessing the objtes's method
		c.display();
		
		

	}

}
