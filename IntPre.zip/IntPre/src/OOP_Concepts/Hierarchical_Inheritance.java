package OOP_Concepts;

//Hierarchical Inheritance contains only one super class and that inherit to multiple subclass

class Vehical
{
	void fuel()
	{
		System.out.println("This vehicals need fuel for run");
	}
}
class Bike extends Vehical
{
	void wheel()
	{
		System.out.println("Bike has 2 wheels");
	}
}
class Auto extends Vehical
{
	void wheels()
	{
		System.out.println("Auto has 3 wheels");
	}
}
class Bus extends Vehical
{
	void wheels()
	{
		System.out.println("Bus has 8 wheels");
	}
}


public class Hierarchical_Inheritance {

	public static void main(String[] args) {
		//it can call auto class method and superclass method
		Auto auto=new Auto();
		auto.fuel();  //call to super class method
		auto.wheels();// call to the auto class method
//		auto.wheel();//compile time error can't call to other class method
		
		//it can call Bus class method and superclass method
		Bus bus=new Bus();
		bus.fuel();
		bus.wheels();
		
		//it can call Bike class method and superclass method
		Bike bike=new Bike();
		bike.fuel();
		bike.wheel();
		
		
		
		

	}

}
