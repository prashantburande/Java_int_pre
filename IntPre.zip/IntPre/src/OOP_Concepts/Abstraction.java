package OOP_Concepts;


/*
 * ->Abstraction in Java is the process of hiding the implementation details and only showing the
 * essential functionality or features to the user. 
 * ->This helps simplify the system by focusing on what an object does rather than how it does it
 * ->The unnecessary details or complexities are not displayed to the user.
 * 
 * ->Achieved through 1)Abstract class and interface
 * ->Abstract class have both abstract method and concrete method
 *Interface*:means collecting of all abstract methods (By default all methods of interface are abstract
 */

abstract class Shape
{
	abstract void draw();
	void display()
	{
		System.out.println("this is the shape");
	}
}
class Circle extends Shape
{
	void draw()
	{
		System.out.println("drawing a circle");
	}
}
class Rectangle extends Shape
{
	void draw()
	{
		System.out.println("drawing a Rectangle");
	}
}
public class Abstraction {

	public static void main(String[] args) {
		Shape circle=new Circle();
		Shape rectangle=new Rectangle();
		
		circle.draw();
		rectangle.draw();

	}

}
