package OOP_Concepts;

//Interface:interface is a blueprint of class that contains abstract methods
//interface are used to achieve 100 % abstraction
//In Interface if you declare method then by default method is abstract no need to use abstract keyword
//**Key features of an interface**
//1)Complete Abstraction:interface contains abstract method and allow no implementation of these methods
//2)Multiple Inheritance:A class can implement multiple interfaces
//3)Default methods and static method(called directly using interface name) in interface java 8 onwards.
//4)Private methods:Interface can have private method java 9 onwards
interface PaymentGateWay
{
    int constat=4566;
	abstract void makePayment(double amount);//abstract method 
	
	//default method 
	default void defaultMethod()
	{
		System.out.println("this is a default method called");
	}
	
	//static method
	static void testVariable()
	{
		System.out.println(constat);
	}
}
class PhonePe implements PaymentGateWay
{
	public void makePayment(double amount) 
	{
		System.out.println("Payment done of $ " + amount + " through phonepe");
	}
}
class GPay implements PaymentGateWay
{
	public void makePayment(double amount) 
	{
		System.out.println("Payment done of $ " + amount + " through GPay");
	}
}

public class Interfaces {

	public static void main(String[] args) {
		PaymentGateWay pg=new PhonePe();
		pg.defaultMethod();
		pg.makePayment(65765.8);
		
		PaymentGateWay gpay=new GPay();
		gpay.makePayment(6567.5);
		
		//calling static method using interface name
		PaymentGateWay.testVariable();
//		PaymentGateWay.constat=54; //error:The final field PaymentGateWay.constat cannot be assigned
	}

}
