package Exception_Handling;


class AIOBE 
{   
    int arr[]={56,45,33,76};
    void dispaly()
    {
    	try
    	{
    		System.out.println(arr[6]);
    	}
    	catch(ArrayIndexOutOfBoundsException e)
    	{
    		System.out.println(e);
    	}
    }
	
}
public class Basic_try_catch 
{

	public static void main(String[] args) 
	{
		AIOBE a=new AIOBE();
		a.dispaly();
		
		try 
		{
			int result=10/0;
		}
		//multiple catch block if 
		catch(ArithmeticException e)
		{
			System.out.println("Cannot devide by zero");
		}
		catch(NullPointerException e)
		{
			System.out.println("Cannot devide by zero");
		}

	}
}


