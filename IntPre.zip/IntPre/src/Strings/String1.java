package Strings;


//String is sequence of character widely used for storing and manipulating textual data.
//Strings is immutable meaning like once a String object is created we cannot modified its value.
public class String1 {

	public static void main(String[] args) {
		//Using String literal
		String str1="Hello";
		String str3="Hello";
		String str4="world";
		//Using new keyword
		String str2=new String("world");
		
		System.out.println(str1);
		System.out.println(str2);
		
		//"H e l l o"
		// 0 1 2 3 4
		int len=str1.length();  //"Hello" length is below
		System.out.println(len); //5  length is 5
		
		System.out.println(str1.charAt(1));//e
		System.out.println(str1.toLowerCase());
		System.out.println(str1.toUpperCase());
		System.out.println(str1.compareTo(str2));
		System.out.println(str1.equals(str3)); //true
		System.out.println(str1.concat(str2));
		
		//"==" compare the addresses
		boolean res=str1==str3;
		System.out.println(res);//true
		boolean res2=str1==str4;
		System.out.println(res2);//false
		// .euqals()compare the objects
 		boolean res3=str2.equals(str4);
		System.out.println(res3);//true
		
		String string="Hello";  //create a string object with value"Hello"
		string=string.concat("World");//create a new string object with value"world"
		System.out.println(string);//HelloWorld
		//when string.concat("world") is called:
		//1:A new object is created with value "HelloWorld"
		//2.The original "Hello" object remains unchanged because string is immutable
		//3.The string reference ,which initially pointed to "Hello", is now updated to point to the 
		//new string object "HelloWolrd" .The Original "Hello" object is still in memory but evenully 
		//be garbage collected if it is no longer refernced.
		
		String string2="Hello";
		string2.concat("world");
		System.out.println(string2);//Hello
		//when string.concat("world") is called:
		//1:A new object is created with value "HelloWorld"
		//but apane result ko string mein assign nahi kiya,sting abhi bhi orginal string ko point karti hai
		

	}

}
