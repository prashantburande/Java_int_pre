package Control_Flow_Statements;

public class Switch_case {

	public static void main(String[] args) {
		int number=29;
		String size;
		switch(number)
		{
		case 29:
			size="medium";
			break;
		
		case 26:
			size="small";
			break;
			
		case 32:
			size="large";
			break;
		
		default:
			size="unknown";
			break;
		}
		System.out.println("Size " + size);

	}

}
