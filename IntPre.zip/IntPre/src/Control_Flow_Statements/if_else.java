package Control_Flow_Statements;

import java.util.Scanner;

public class if_else {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the age");
		int age=sc.nextInt();
		if(age<18)
		{
			System.out.println("you cant vote " + "age is " + age);
		}
		else
		{
			System.out.println("you can vote " + age);
		}
		

	}

}
