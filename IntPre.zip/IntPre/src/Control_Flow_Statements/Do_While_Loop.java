package Control_Flow_Statements;

public class Do_While_Loop {

	public static void main(String[] args) {
		int num=2;
		do {
			System.out.println("before cond checking " +num);
			num++;
		}while(num<8);

	}

}
