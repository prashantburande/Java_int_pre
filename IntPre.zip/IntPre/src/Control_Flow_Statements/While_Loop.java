package Control_Flow_Statements;

public class While_Loop {

	public static void main(String[] args) {
		int num=2;
		int i=1;
		while(i<=10)
		{
			int result=num*i;
			System.out.println(result);
			i++;
		}		
	}

}
