package Control_Flow_Statements;

public class Enhance_for_Loop {

	public static void main(String[] args) {
		int arr[]= {5,7,4,8,4,8};
		for(int list:arr)
		{
			System.out.print(list +" ");
		}

	}

}
