package Control_Flow_Statements;

import java.util.Scanner;

public class nested_if_else {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the employee role");
		String role=sc.next();
		if(role.equals("backend_dev")) 
		{
			System.out.println("salary is 20k");
		}
		else if(role.equals("frontend_dev"))
		{
			System.out.println("salary is 18k");
		}
		else if(role.equals("QA"))
		{
			System.out.println("salary is 16k");
		}
		else
		{
			System.out.println("Role is not found pls check role once to check salary");
		}

	}

}
