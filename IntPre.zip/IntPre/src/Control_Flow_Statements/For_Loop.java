package Control_Flow_Statements;

public class For_Loop {

	public static void main(String[] args) {
		int num=2;
	    int result = 0;
	    System.out.println("table of " +num+ " is below");
		for(int i=1;i<=10;i++)
		{
			result=num*i;
			System.out.println(result);
		}
		
			

	}

}
